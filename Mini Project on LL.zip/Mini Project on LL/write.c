#include "header.h"
E* write(E* start){
	FILE *fp1;
	fp1=fopen("emp.dat","w+");
	E *temp;
	char c,str[10];
	temp=start;
	while(temp!=NULL)
	{
		sprintf(str,"%d",temp->data);
		fputs(str,fp1);
		fputc('\n',fp1);
		temp=temp->next;
	}
	rewind(fp1);
	while((c=fgetc(fp1))!=EOF)
		printf("%c",c);
	fclose(fp1);
	return start;
}
