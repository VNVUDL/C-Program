#include "header.h"
E* delData(E *start){
	E *temp1,*temp;
	int i=0,pos,count=0;
	if(start==NULL)
		printf("list is already empty\n");
	printf("enter the position:\n");
	scanf("%d",&pos);
	if(pos==1)
	{
		temp=start;
		start=start->next;
		free(temp);
	}
	else
	{
		temp=start;
		while(temp!=NULL)
		{
			count++;
			temp=temp->next;
		}
		if(count<pos || pos<0)
			printf("invalid \n");
		else
		{
			temp=start;
			for(i=1;i<pos-1;i++)
				temp=temp->next;
			temp1=temp->next;
			temp->next=temp1->next;
			free(temp1);
		}
	}

	return start;
}
