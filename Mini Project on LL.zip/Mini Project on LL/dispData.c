#include "header.h"
E* dispData(E *start){
	char c,str[10];
	E *temp;
	temp=start;
	while(temp!=NULL)
	{
		printf("%d\n",temp->data);
		temp=temp->next;
	}
	return start;
}
