#include "header.h"
void main()
{
	start=NULL;
	int choice;
	char ch;
	start=read();
	do{
		printf("1.Add\n2.Delete\n3.Modify\n4.Display in LL\n5.Display from file\n6.exit\n");
		printf("Enter the Choice:");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1: start=addData(start);
				break;
			case 2:	start=delData(start);
				break;
			case 3: start=modifyData(start);
			        break;
			case 4: start=dispData(start);
				break;
			case 5: start=write(start);
				break;
			case 6: exit(0);
			        break;
			default: printf("Wrong Choice\n");
				 break;
		}
		printf("Do you want to continue:(y/n):");
		scanf(" %c",&ch);  
	}while(ch!='n');
}
