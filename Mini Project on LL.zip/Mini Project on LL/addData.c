#include "header.h"
E* addData(E *start){
	int pos,count=0,i;
	E *temp1,*temp;
	new_node=(E *)malloc(sizeof(E));
	printf("enter the data:\n");
	scanf("%d",&new_node->data);
	new_node->next=NULL;
	printf("enter the position:\n");
	scanf("%d",&pos);
	if(start==NULL)
	{
		start=new_node;
		current=new_node;
	}
	temp=start;
	while(temp!=NULL)
	{
		count++;
		temp=temp->next;
	}
	if(count+1<pos || pos<0)
		printf("invalid position\n");
	else
	{
		temp=start;
		if(pos==1)
		{
			new_node->next=start;
			start=new_node;
		}
		else
		{
			for(i=1;i<pos-1;i++)
				temp=temp->next;
			temp1=temp->next;
			temp->next=new_node;
			new_node->next=temp1;
		}
	}
	return start;
}
