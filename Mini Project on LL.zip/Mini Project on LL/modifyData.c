#include "header.h"
E* modifyData(E *start){
	int flag=0,old,new;
	E *temp;
	printf("enter the data to be modified:\n");
	scanf("%d",&old);
	printf("\nenter the new data:");
	scanf("%d",&new);
	if(start==NULL)
		printf("Can't modify data");
	else{
		temp=start;
		while(temp!=NULL)
		{
			if(temp->data==old){
				temp->data=new;
			}
			temp=temp->next;
		}
	}
	return start;

}
