#include "header.h"
E* read()
{
	FILE *fp;
	int j;
	fp=fopen("emp1.dat","r");
	E *temp;
	fscanf(fp,"%d",&j);
	while(!feof(fp)){
		new_node=(E *)malloc(sizeof(E));		
		new_node->data=j;
		if(start==NULL)
		{
			 new_node->next=NULL;
			start=new_node;
		}
		else
		{
			temp=start;
			while(temp->next!=NULL)
				temp=temp->next;
			temp->next=new_node;
			 new_node->next=NULL;
		}
		fscanf(fp,"%d",&j);
	}	
	fclose(fp);
	return start;
}
