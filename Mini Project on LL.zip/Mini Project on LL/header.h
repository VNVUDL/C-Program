#include<stdio.h>
#include<stdlib.h>
typedef struct emp{
 int data;
 struct emp *next;
}E;
E *start,*new_node,*current;
E* read();
E* write(E *);
E* addData(E *);
E* delData(E *);
E* modifyData(E *);
E* dispData(E *);
