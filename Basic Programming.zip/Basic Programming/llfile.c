#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void create();
void display();
void insert_beg();
void insert_end();
void insert_mid();
void delete();
void search();
void update();
struct data
{
	char name[100];
	int num;
	long int mob;
	struct data *next;
}*start=NULL,*current,*end,*temp,*temp1,*new,*temp2,e;

void main()
{
	int n;
	create();
	printf("1.create a node\n2.display\n3.insert at the beg\n4.insert at end\n5.insert at middle\n6.delete\n7.searching\n8.exit\n");
	while(1)
	{

		printf("enter the choice(1-8):\n");
		scanf("%d",&n);
		switch(n)
		{
			case 1: create();
				break;
			case 2: display();
				break;
			case 3:insert_beg();
			       break;
			case 4:insert_end();
			       break;
			case 5:
			       insert_mid();
			       break;
			case 6:delete();
			       break;
			case 7:search();
			       break;
			case 8:exit(0);
		}
	}
} 
void create()
{
	start=NULL;
	FILE *fp;
	fp=fopen("file.txt","r");
	fscanf(fp,"%s%d%ld",&e.name,&e.num,&e.mob);
	while(!feof(fp))
	{
		current=(struct data *)malloc(sizeof(struct data));
		current->next=NULL;
		strcpy(current->name,e.name);
		current->num=e.num;
		current->mob=e.mob;

		if(start==NULL)
		{
			start=current;
			end=current;
			//	current->next=NULL;
		}
		else 
		{
			end->next=current;
			end=current;
		}
		fscanf(fp,"%s%d%ld",&e.name,&e.num,&e.mob);


	}
	fclose(fp);

}

void display()
{
	if(start==NULL)
		printf("list is empty\n");
	temp=start;
	//printf("%s",temp);


	while(temp!=NULL)
	{
		printf("%s %d %ld\n",temp->name,temp->num,temp->mob);
		temp=temp->next;
	}

}
void insert_beg()
{
	current=(struct data *)malloc(sizeof(struct data));
	printf("enter the name num and mobile number :\n");
	scanf("%s%d%ld",current->name,&current->num,&current->mob);
	if(start==NULL)
	{
		start=current;
		end=current;
		current->next=NULL;
	}
	else
	{
		current->next=start;
		start=current;
	}
}
void insert_end()
{
	current=(struct data *)malloc(sizeof(struct data));
	printf("enter the name num and mobile number :\n");
	scanf("%s%d%ld",current->name,&current->num,&current->mob);
	if(start==NULL)
	{
		start=current;
		end=current;
		current->next=NULL;
	}
	else
	{
		end->next=current;
		current->next=NULL;
	}
}
void insert_mid()
{
	int pos,count=0,i;
	current=(struct data *)malloc(sizeof(struct data));
	printf("enter the name num and mobile number :\n");
	scanf("%s%d%ld",current->name,&current->num,&current->mob);
	printf("enter the position:\n");
	scanf("%d",&pos);
	if(start==NULL)
	{
		start=current;
		end=current;
		current->next=NULL;
	}

	temp=start;
	while(temp!=NULL)
	{
		count++;
		temp=temp->next;
	}
	//printf("%d",count);

	if(count+1<pos || pos<0)
	{
		printf("invalid position\n");
	}


	else
	{
		temp=start;
		if(pos==1)
		{
			current->next=start;
			start=current;
		}
		else
		{
			for(i=1;i<pos-1;i++)
			{

				temp=temp->next;
			}
			temp1=temp->next;
			temp->next=current;
			current->next=temp1;
		}
	}
	update();



}
void delete()
{
	int i=0,pos,count=0;

	if(start==NULL)
		printf("list is already empty\n");
	// printf("enter the name num and mobile number :\n");
	//scanf("%s%d%ld",current->name,&current->num,&current->mob);
	printf("enter the position:\n");
	scanf("%d",&pos);
	if(pos==1)
	{
		temp=start;
		start=start->next;
		free(temp);
	}
	/*	if(pos==count)
		{
		for(i=1;i<count;i++)
		temp=temp->next;
		temp1=temp->next;
		temp->next=NULL;
		free(temp1);
		}*/
	else
	{
		temp=start;
		while(temp!=NULL)
		{
			count++;
			temp=temp->next;
		}
		//	printf("%d",count);
		if(count<pos || pos<0)
			printf("invalid \n");
		else
		{


			temp=start;

			for(i=1;i<pos-1;i++)
				temp=temp->next;
			temp1=temp->next;
			temp->next=temp1->next;
			free(temp1);
		}
	}
	update();

}
void search()
{
	char r[100];
	int flag=0,num;
	printf("enter the name to be seached:\n");
	scanf("%s",&r);
	//	printf("enter the num:\n");
	//	scanf("%d",&num);
	temp=start;
	//	printf("%s",temp);
	while(temp!=NULL)
	{
		//	printf("%s",temp);
		if(strcmp(temp->name,r)==0)
		{
			//			printf("%s %s",r,temp->name);
			flag++;
			printf("found\n");
			printf("%s %d %ld\n",temp->name,temp->num,temp->mob);
		}
		temp=temp->next;
	}
	if(flag==0)
		printf("not found\n");
}
void update()
{
	FILE *fp;
        fp=fopen("file.txt","w+");
        temp=start;
        while(temp!=NULL)
        {
                fprintf(fp,"%s %d %ld\n",temp->name,temp->num,temp->mob);
                temp=temp->next;
        }
        fclose(fp);
}











