#include<stdio.h>
#include<string.h>
void main(){
	char str[]="I Am alWays 24#7 Busy.";
	char words[10][30],new[100],out[10][30];
	int i=0,j=0,k=0,m=0,l=0;
	while(str[i]!='\0'){
		if(str[i]==' '){
			words[k][j]='\0';
			k++;
			j=0;
		}
		else{
			words[k][j]=str[i];
			j++;
		}
		i++;
	}
	printf("enter the option:");
	scanf("%d",&m);
	switch(m){
		case 1:
			for(i=0;i<=k;i++)
			{
				int l=strlen(words[i]);
				out[i][l]='\0';
				j=0;
				while(words[i][j]!='\0'){
					out[i][l-1]=words[i][j];
					l--;
					j++;			
				}
				j=0;
				while(words[i][j]!='\0'){
					if(isupper(words[i][j]))
						out[i][j]=toupper(out[i][j]);
					else if(islower(words[i][j]))
						out[i][j]=tolower(out[i][j]);
					j++;
				}
				printf("%s\n",out[i]);
			}
			break;
		case 0:
			for(i=0;i<=k;i++)
			{
				int l=strlen(words[i]);
				out[i][l]='\0';
				j=0;
				while(words[i][j]!='\0'){
					out[i][l-1]=words[i][j];
					l--;
					j++;
				}
				printf("%s\n",out[i]);
			}
			break;
	}

}
