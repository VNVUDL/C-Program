#include<stdio.h>
#include<string.h>
#include<string.h>
void main()
{
	int len,rows=0,cols=0,i,sum=0,j,n1,a[100]={0};
	char str1[100][100],input1[100],buffer[100],b[100];
	printf("enter the string:\n");
	scanf("%[^\n]s",input1);
	len=strlen(input1);
	for(i=0;i<len;i++)
	{
		input1[i]=tolower(input1[i]);
	}
	input1[i]='\0';
//	printf("%s\n",input1);
	for(i=0;i<=len;i++)
	{
		if(input1[i]==' ' || input1[i]=='\0')
		{
			str1[rows][cols]='\0';
			rows++;
			cols=0;
			continue;
		}
		str1[rows][cols]=input1[i];
		cols++;
	}
	for(i=0;i<rows;i++)
		printf("%s\n",str1[i]);
//	printf("%d %d\n",rows,cols);
	for(i=0;i<rows;i++)
	{
		n1=strlen(str1[i]);
//		printf("%d\n",n1);
		if(n1%2==0)
		{
			sum=0;
			for(j=0;j<n1/2;j++)
			{
				sum=sum+abs(str1[i][j]-str1[i][n1-j-1]);
			}
		//	printf("%d\n",sum);
			a[i]=sum;
			//sprintf(buffer,100,a[i]);
		//	printf("%d %d\n",a[i],i);
		
		}
		else
		{
			sum=0;
			for(j=0;j<n1/2;j++)
			{
				sum=sum+abs(str1[i][j]-str1[i][n1-j-1]);
	
			}
			sum=sum+str1[i][n1/2]-96;
		//	printf("%d\n",sum);
			a[i]=sum;
			//sprintf(buffer,100,a[i]);
		//	printf("%d %d\n",a[i],i);
			
		}
	}
	int k=0;
	while(a[k]!=0)
	{
		k++;
	}
//	printf("%d",k);
	for(i=0;i<k;i++)
	{
		sprintf(buffer,"%d",a[i]);
		strcat(b,buffer);
	}
//	printf("%s",b);
	int p=atoi(b);
	printf("%d",p);
}



