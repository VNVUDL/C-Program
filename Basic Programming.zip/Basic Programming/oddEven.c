#include<stdio.h>
#include<stdlib.h>
void main(){
	int num,j=0,i=0;
	printf("enter the num:");
	scanf("%d",&num);
	int n=num;
	int k;
	static int a[100];
	while(num!=0){
		a[j]=num%10;
		num=num/10;
		j++;
	}k=j-1;
	static int b[100];
	for(i=1;i<=j;i++){
		b[i]=a[k];k--;
	}
	static char str[100];
	if(n<0)
		str[0]='N';
	else if(n>0)
		str[0]='P';
	for(j=1;j<=i;j++){
		if(b[j]%2==0)
			str[j]='E';
		else if(b[j]%2!=0)
			str[j]='O';
	}
	str[j-1]='\0';
	printf("%s",str);
}
			
