#include<stdio.h>
#include<stdlib.h>
void main(){
	int input1,sum=0,rem;
	printf("Enter the number:");
	scanf("%d",&input1);
	do{
		sum=0;
		while(input1!=0)
		{
			rem=input1%10;
			sum=sum+rem;
			input1=input1/10;
		}
		input1=sum;
	}while(sum>9);
	printf("%d",sum);
}
