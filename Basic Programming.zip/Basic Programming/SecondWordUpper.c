#include<stdio.h>
#include<string.h>
void main(){
	char str[100]="Welcome Wipro Technologies";
	char words[10][30];
	int i=0,j=0,k=0;
	while(str[i]!='\0'){
		if(str[i]!=' '){
			words[k][j]=str[i];
			j++;
		}
		 else{
                        words[k][j]='\0';
                        k++;
                        j=0;
                }
		i++;
	}j=0;
	while(words[0][j]!='\0'){
		words[0][j]=toupper(words[0][j]);
			j++;
	}
	printf("%s\n",words[0]);
}
