#include<stdio.h>
void main(){
	static int b[100]={0};
	int n,i=0,count=0,a[100],j=0;
	printf("Enter the number of elements:");
	scanf("%d",&n);
	printf("Enter the elements:\n");
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	for(i=0;i<n;i++){
		if(a[i]<a[i+1]){
			count++;
			b[i]=count;
			//printf("%d\t",b[i]);
		}
		else if(a[i]>a[i+1]){
			count=0;
			b[i]=count;
		    }
	}
	int h=0;
	for(j=0;j<=i;j++)
		if(h<b[j])
			h=b[j];
	printf("%d",h);
}


