#include<stdio.h>
#include<stdlib.h>
void main(){
	int input1,input2,input3,i=0,j=0,k=0,t;
	int a[100],b[100],count=0;
	printf("Enter the number to be searched:\n");
	scanf("%d",&input1);
	printf("Enter the range:\n");
	scanf("%d%d",&input2,&input3);
	for(i=input2;i<=input3;i++){
		t=findPrime(i);
		if(t){
			a[j]=t;
			j++;
		}
	}
	for(i=0;i<j;i++){
		if(a[i]>9){
			while(a[i]!=0){
				b[k]=a[i]%10;
				k++;
				a[i]=a[i]/10;
			}
		}
		else{
			b[k]=a[i];
			k++;
		}
	}
	for(i=0;i<k;i++){		
		if(input1==b[i])
			count++;
	}
	printf("%d",count);
}
int findPrime(int n){
	int j,c=0;
	for(j=3;j<=n/2;j++){
		if(n%j==0)
			c++;
	}
	if(c==0) return n;
	else return 0;	
}
