#include<stdio.h>
#include<string.h>
void main()
{
	char str[]="wipro technologies";
	static char words[10][30],out[10][30],output[100][100],output1[100][100],word[100];
	char t=NULL,x=NULL;
	int i=0,j=0,k=0,m=0,n=0,l=0;
	while(str[i]!='\0')
	{
		if(str[i]!=' ')
			words[k][j++]=str[i];
		else if(str[i]==' ')
		{
			words[k][j]='\0';
			k++;
			j=0;
		}
		i++;
	}l=0;
	for(i=0;i<=k;i++)
	{
		j=0;m=0;
		while(words[i][j]!='\0'){
			t=words[i][j];
			if(t){
				output[l][m]=t;
				m++;				
				j=j+2;
			}
		}output[l][m]='\0';
		j=1;n=0;
		while(words[i][j]!='\0'){
			x=words[i][j];
			if(x){
				output1[l][n]=x;
				n++;
				j=j+2;
			}
		}output1[l][n]='\0';n=0;l=l+1;
	}k=0;
	int input2,b=0,len,c=0;
	char word1[100];
	printf("Enter the option:");
	scanf("%d",&input2);
	switch(input2){
		case 0:
			for(i=0;i<=l;i++){
				j=0;
				while(output[i][j]!='\0'){
					word[k]=output[i][j];
					k++;
					j++;
				}j=0;
				while(output1[i][j]!='\0'){
					word[k]=output1[i][j];
					k++;j++;
				}word[k]=' ';k=k+1;
			}word[k]='\0';
			len=strlen(word)-1;
			for(b=0;b<len-1;b++){
			word1[c]=word[b];
			c++;	
			}word1[c]='\0';	
			printf("%s",word1);
			break;
		case 1:
			for(i=0;i<=l;i++){
				j=0;
				while(output[i][j]!='\0'){
					if(output[i][j]!=' '){
						word[k]=output[i][j];
						k++;
					}j++;
				}j=strlen(output1[i])-1;
				while(j>=0){
					word[k]=output1[i][j];
					k++;j--;
				}word[k]=' ';k=k+1;
			}word[k]='\0';
			 len=strlen(word)-1;
                        for(b=0;b<len-1;b++){
                        word1[c]=word[b];
                        c++;
                        }word1[c]='\0';
                        printf("%s",word1);
                        break;
	}
}
