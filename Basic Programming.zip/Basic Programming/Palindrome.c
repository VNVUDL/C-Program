#include<stdio.h>
#include<string.h>
void main(){
	char str[100],t[100];
	int i=0,flag=0,k=0;
	printf("Enter the string:");
	scanf("%s",str);
	while(str[i]!='\0'){
		str[i]=toupper(str[i]);
		i++;
	}
	int l=i;
	printf("%d\n",l);
	for(i=l-1;i>=0;i--){
		t[k]=str[i];
		k++;
	}
	t[k]='\0';
	printf("%s",t);
	for(i=0;i<strlen(str);i++){
		if(t[i]==str[i])
			flag=1;
		else
			flag=0;
	}
	if(flag==1)
		printf("\nYES");
	else
		printf("\nNO");
}
