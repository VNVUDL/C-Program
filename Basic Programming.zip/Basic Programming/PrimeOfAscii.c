#include<stdio.h>
#include<string.h>
int findPrime(int);
void main(){
	char *str="ABCDE";
	static char c[1000];
	static int a[20],b[20],s[10],s1[10];
	int i=0,j=0,k=0,t,sum=0;
	while(str[i]!='\0'){
		a[i]=(int)str[i];i++;
	}
	for(j=0;j<i;j++){
		t=findPrime(a[j]);
		if(t){
		sum=sum+t;
		b[k]=t;k++;
		}
	}j=0;
	for(i=0;i<k;i++){
		c[j]=b[i];
		j++;
	}	        	
        c[j]=':';j=j+1;i=0;
	while(sum!=0){
		s[i]=sum%10;
		sum=sum/10;
		i++;
	}
	for(k=0;k<i;k++){
		s1[k]=s[i-k-1];
		c[j]=s1[k]+48;
		j++;
	}	
	printf("%s",c);	
}
int findPrime(int n){
	int j,count=1;
	for(j=2;j<n/2;j++)	
		if(n%j==0) count++;		
	if(count>1) return 0;
	else return n;
}
