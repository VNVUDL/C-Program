#include<stdio.h>
#include<string.h>
void main(){
	int i=0,j=0,k=0,num=31;
	char str[]="Today is Wednesday";
	char words[10][20];
	char out[100];
	while(str[i]!='\0'){
		if(str[i]!=' '){
			words[k][j]=str[i];
			j++;
		}
		else if(str[i]==' '){
			words[k][j]='\0';
			k=k+1;
			j=0;
		}
		i++;
	}
	int n1=num/10;k=0;
	n1=n1-1;
	for(j=(strlen(words[n1])/2)-1;j>=0;j--){
		out[k]=words[n1][j];
		k++;
	}j=strlen(words[n1])/2;
	while(words[n1][j]!='\0'){
		out[k]=words[n1][j];
		k++;j++;
	}
	//out[k]=' ';k=k+1;
	n1=num%10;
	n1=n1-1;
	for(j=(strlen(words[n1])/2)-1;j>=0;j--){
		out[k]=words[n1][j];
	        k++;
        }j=strlen(words[n1])/2;
	while(words[n1][j]!='\0'){
                out[k]=words[n1][j];
	        k++;j++;
        }
	out[k]='\0';
	printf("%s",out);
}
